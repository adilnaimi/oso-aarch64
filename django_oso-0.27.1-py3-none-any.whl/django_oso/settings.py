from django.conf import settings

OSO_RELOAD_SERVER = getattr(settings, "OSO_RELOAD_SERVER", True)
